#!/bin/bash

# =====================================
# PV_OS Restore Engine V1.0
# =====================================


PROJECT_DIR="$HOME/PV_OS_MASTER"


echo "================================="
echo "PV_OS Restore"
echo "================================="


echo "Latest backup:"

ls -lt "$PROJECT_DIR/backup/history" | head


echo ""
echo "Latest snapshot:"

ls -lt "$PROJECT_DIR/snapshots" | head


echo ""
echo "Restore preparation complete."


echo ""
echo "Current PV_OS context:"


cat "$PROJECT_DIR/backup/latest/PV_OS_BACKUP_MAP_V1.0.md"


echo ""
echo "================================="
echo "PV_OS Restore Finished"
echo "================================="
